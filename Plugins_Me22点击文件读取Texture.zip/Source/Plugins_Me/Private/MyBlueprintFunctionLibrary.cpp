// Fill out your copyright notice in the Description page of Project Settings.


#include "MyBlueprintFunctionLibrary.h"

/*public*/
/*TArray<FString>UGenericArrayLibrary*/
/*TArray<FString> UGenericArrayLibrary;*/





		TArray<FString> UMyBlueprintFunctionLibrary::OpenFile()
	{
		TArray<FString> FilePath; //ѡ���ļ�·��
		FString fileType = TEXT("*.*"); //�����ļ�����
		FString defaultPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectDir()); //�ļ�ѡ�񴰿�Ĭ�Ͽ���·��
		IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
		bool bSuccess = DesktopPlatform->OpenFileDialog(nullptr, TEXT("���ļ�"), defaultPath, TEXT(""), *fileType, EFileDialogFlags::None, FilePath);

		for (auto& name : FilePath)
		{
			UE_LOG(LogTemp, Warning,
				TEXT("%s"), *name);
		}
		if (bSuccess)
		{
			//�ļ�ѡ��ɹ����ļ�·�� path
			UE_LOG(LogTemp, Warning, TEXT("Success"));
		}
		return FilePath;
		}


	
		FString UMyBlueprintFunctionLibrary::ReadFile(FString path)
		{

			FString resultString;
			FFileHelper::LoadFileToString(resultString, *path);
			return resultString;

		}

		bool UMyBlueprintFunctionLibrary::WriteFile(FString saveFile, FString path)
		{
			bool success;
			success = FFileHelper::SaveStringToFile(saveFile, *path);
			return success;
		}

		TArray<FString> UMyBlueprintFunctionLibrary::ReadFileArray(FString path)//��ȡ�ļ�(�ַ�����)
		{

			TArray<FString> results;
			FFileHelper::LoadFileToStringArray(results, *path);
			return results;
		}

		bool UMyBlueprintFunctionLibrary::WriteFileArray(TArray<FString> saveFile, FString path)//д���ļ�(�ַ�����)
		{

			return FFileHelper::SaveStringArrayToFile(saveFile, *path);
		}




		FString UMyBlueprintFunctionLibrary::GetFilePath(FString path)//��ȡ�ļ�����·��
		{
			FString Result;
			Result = FPaths::GetPath(*path);
			return Result;
		}

		FString UMyBlueprintFunctionLibrary::GetFileName(FString InPath, bool bRemovePath)//��ȡ�ļ�����������׺
		{
			return FPaths::GetBaseFilename(*InPath, bRemovePath);
		}

		FString UMyBlueprintFunctionLibrary::GetFileExtension(FString InPath, bool bIncludeDot)//��ȡ�ļ���׺
		{
			return FPaths::GetExtension(*InPath, bIncludeDot);
		}

		void UMyBlueprintFunctionLibrary::CreatFolder(FString FolderName)//����һ���ļ���
		{
			FString Path = FPaths::ProjectDir() / *FolderName;
			Path = FPaths::ConvertRelativePathToFull(*Path);
			FPlatformFileManager::Get().GetPlatformFile().CreateDirectoryTree(*Path);
		}

		void UMyBlueprintFunctionLibrary::DeleteFolder(FString FolderName)//ɾ��һ���ļ���
		{
			FString Path = FPaths::ProjectDir() / *FolderName;
			Path = FPaths::ConvertRelativePathToFull(*Path);
			FPlatformFileManager::Get().Get().GetPlatformFile().DeleteDirectoryRecursively(*Path);
		}

		bool UMyBlueprintFunctionLibrary::MoveFileTo(FString To, FString From)//�ƶ��ļ�
		{
			return IFileManager::Get().Move(*To, *From);
		}

		TArray<FString> UMyBlueprintFunctionLibrary::FindFolder(FString Path, FString Filter, bool Files, bool Directory)//�����ļ�Ŀ¼�µ������ļ�
		{
			TArray<FString> FilePathList;
			FilePathList.Empty();
			FFileManagerGeneric::Get().FindFilesRecursive(FilePathList, *Path, *Filter, Files, Directory);
			return FilePathList;

		}

		TArray<FString> UMyBlueprintFunctionLibrary::GetFolderFiles(FString Path)//�����ļ�Ŀ¼�������ļ��޷�ɾѡ����
		{
			TArray<FString> Files;
			FPaths::NormalizeDirectoryName(Path);
			IFileManager& FileManager = IFileManager::Get();
			FString FinalPath = Path / TEXT("*");
			FileManager.FindFiles(Files, *FinalPath, true, true);
			return Files;
		}

