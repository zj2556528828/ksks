// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "MyBlueprintFunctionLibrary.h"
#include "MyMyBlueprintFunctionLibrary.generated.h"

/**
 * 
 */
UCLASS()
class PLUGINS_ME_API UMyMyBlueprintFunctionLibrary : public UMyBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
};
