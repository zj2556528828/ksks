// Copyright Epic Games, Inc. All Rights Reserved.

#include "Plugins_Me.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Plugins_Me, "Plugins_Me" );
