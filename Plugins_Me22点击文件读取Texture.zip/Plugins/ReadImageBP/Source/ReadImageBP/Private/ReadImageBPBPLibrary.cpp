// Copyright Epic Games, Inc. All Rights Reserved.

#include "ReadImageBPBPLibrary.h"
#include "ReadImageBP.h"
#include "Engine/Texture2D.h"
#include "Core\Public\HAL\PlatformFilemanager.h"
#include "IImageWrapper.h"
#include "IImageWrapperModule.h"



UReadImageBPBPLibrary::UReadImageBPBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

float UReadImageBPBPLibrary::ReadImageBPSampleFunction(float Param)
{
	return Param;
}


FString UReadImageBPBPLibrary::getProjectDir() {
	FString dirPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectDir());
	return dirPath;
}

FString UReadImageBPBPLibrary::getPakRootDir() {
	FString dirPath = FPaths::ConvertRelativePathToFull(FPaths::RootDir());
	return dirPath;
}
 
#pragma region TEXT
UTexture2D* UReadImageBPBPLibrary::loadTexture2D(const FString path, bool& isValid, int32& outWidth, int32& outHeight) {   //("ͨ������ͼƬת����UTexture2D")
	UTexture2D* texture2D = nullptr;
	IImageWrapperModule& imageWrapperModule = FModuleManager::LoadModuleChecked<IImageWrapperModule>(FName("ImageWrapper"));
	IImageWrapperPtr imageWrapper = imageWrapperModule.CreateImageWrapper(EImageFormat::PNG);

	TArray<uint8> OutArray;
	if (FFileHelper::LoadFileToArray(OutArray, *path)) {
		if (imageWrapper.IsValid() &&
			imageWrapper->SetCompressed(OutArray.GetData(), OutArray.Num())) {
			TArray<uint8> uncompressedRGBA;
			if (imageWrapper->GetRaw(ERGBFormat::RGBA, 8, uncompressedRGBA)) {
				const TArray<FColor> uncompressedFColor = uint8ToFColor(uncompressedRGBA);
				outWidth = imageWrapper->GetWidth();
				outHeight = imageWrapper->GetHeight();
				texture2D = TextureFromImage(imageWrapper->GetWidth(), imageWrapper->GetHeight(), uncompressedFColor, true);
			}
		}
	}
	return texture2D;
}
#pragma endregion

#pragma region TEXT("��uint8����תΪ��ɫ����")
TArray<FColor> UReadImageBPBPLibrary::uint8ToFColor(const TArray<uint8> origin) {
	TArray<FColor> uncompressedFColor;
	uint8 auxOrigin;
	FColor auxDst;

	for (int i = 0; i < origin.Num(); i++) {
		auxOrigin = origin[i];
		auxDst.R = auxOrigin;
		i++;
		auxOrigin = origin[i];
		auxDst.G = auxOrigin;
		i++;
		auxOrigin = origin[i];
		auxDst.B = auxOrigin;
		i++;
		auxOrigin = origin[i];
		auxDst.A = auxOrigin;
		uncompressedFColor.Add(auxDst);
	}

	return  uncompressedFColor;

}
#pragma endregion

#pragma region TEXT("����ɫ���鸳ֵ��Texture")
UTexture2D* UReadImageBPBPLibrary::TextureFromImage(const int32 SrcWidth, const int32 SrcHeight, const TArray<FColor>& SrcData, const bool UseAlpha) {

	// ����Texture2D����
	UTexture2D* MyScreenshot = UTexture2D::CreateTransient(SrcWidth, SrcHeight, PF_B8G8R8A8);

	// ��ס�������ݣ��Ա��޸�
	uint8* MipData = static_cast<uint8*>(MyScreenshot->PlatformData->Mips[0].BulkData.Lock(LOCK_READ_WRITE));

	// ������������
	uint8* DestPtr = NULL;
	const FColor* SrcPtr = NULL;
	for (int32 y = 0; y < SrcHeight; y++) {
		DestPtr = &MipData[(SrcHeight - 1 - y) * SrcWidth * sizeof(FColor)];
		SrcPtr = const_cast<FColor*>(&SrcData[(SrcHeight - 1 - y) * SrcWidth]);
		for (int32 x = 0; x < SrcWidth; x++) {
			*DestPtr++ = SrcPtr->B;
			*DestPtr++ = SrcPtr->G;
			*DestPtr++ = SrcPtr->R;
			if (UseAlpha) {
				*DestPtr++ = SrcPtr->A;
			}
			else {
				*DestPtr++ = 0xFF;
			}
			SrcPtr++;
		}
	}

	// ��������
	MyScreenshot->PlatformData->Mips[0].BulkData.Unlock();
	MyScreenshot->UpdateResource();

	return MyScreenshot;
}
#pragma endregion



static IImageWrapperPtr GetImageWrapperByExtention(const FString InImagePath)
{
	IImageWrapperModule& ImageWrapperModule = FModuleManager::LoadModuleChecked<IImageWrapperModule>(FName("ImageWrapper"));
	if (InImagePath.EndsWith(".png"))
	{
		return ImageWrapperModule.CreateImageWrapper(EImageFormat::PNG);
	}
	else if (InImagePath.EndsWith(".jpg") || InImagePath.EndsWith(".jpeg"))
	{
		return ImageWrapperModule.CreateImageWrapper(EImageFormat::JPEG);
	}
	else if (InImagePath.EndsWith(".bmp"))
	{
		return ImageWrapperModule.CreateImageWrapper(EImageFormat::BMP);
	}
	else if (InImagePath.EndsWith(".ico"))
	{
		return ImageWrapperModule.CreateImageWrapper(EImageFormat::ICO);

	}
	else if (InImagePath.EndsWith("exr"))
	{
		return ImageWrapperModule.CreateImageWrapper(EImageFormat::EXR);
	}
	else if (InImagePath.EndsWith(".icns"))
	{
		return ImageWrapperModule.CreateImageWrapper(EImageFormat::ICNS);
	}
	return nullptr;
}

